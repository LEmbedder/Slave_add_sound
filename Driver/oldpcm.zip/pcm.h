#ifndef __PCM_H
#define __PCM_H	 
#include "stm32f10x.h"


#ifdef __cplusplus
extern "C" {
#endif

typedef short PCM_DATA;
#define C_PCM_BUF_SIZE 2048	
	
#define B_pcm_RUD (1<<0)	//rupdown
#define B_pcm_buf1 (1<<1)	//1:buf1 filled 0:invalid
#define B_pcm_buf2 (1<<2)	//1:buf2 filled 0:invalid
#define B_pcm_whichbuf (1<<3)	//0:buf1  1:buf2
#define B_pcm_IsPlaying (1<<4)	//0:end 1:playing	
#define B_pcm_loop (1<<5)	//0:not loop 1:loop	
	
int pcm_Init(void);
int pcm_checkbuf(PCM_DATA *pcm_buf);
void pcm_open(void);	
void pcm_close(void);	
	
void pcm_Play(u16 index);
int pcm_IsPlaying(void);
void pcm_checkmsg(void);
u16 IsVoiceBusy(void);
void PlayVoice(u16 index);
void StopVoice(void);	
void pcm_SetLoop(void);		
	
#ifdef __cplusplus
}
#endif


#endif
