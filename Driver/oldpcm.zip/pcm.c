#include "pcm.h"
#include "source.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_dac.h"
#include "misc.h"
#include "File.h"
#include "CMOS.h"

#define CR_CLEAR_Mask              ((unsigned int)0x00000FFE)
#define SWTRIGR_SWTRIG_Set         ((unsigned int)0x00000001)
#define CR_EN_Set                  ((unsigned int)0x00000001)

//u8 *p_pcm_data;	//
#define C_pcm_bufsize 2048	//1024

static u32 _pcm_dataAddr=0x00;
static u32 _pcm_backAddr=0x00;
static u16 _pcm_flags=0x0000;
static u8 _pcm_buf[C_pcm_bufsize*2];
static u16 _pcm_currenrbuf=0;	//0:fill buf1 C_pcm_bufsize:fill buf2
static u16 _pcm_pindex=0;
static u32 _pcm_filelength=0;
static u32 _pcm_backlength=0;


static void pcm_Init_Shutdown_Pin(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIOB->BSRR = GPIO_Pin_10;
}
//*for test start
extern void _binary_asc5x7_bin_start(void);

int GettestData(u8 *pbuf,int addr,int length)
{
	short *src=(short *)addr;
	short *des=(short *)pbuf;
	int cnt=length/2;
	short data;
	short realdata;
	for(int i=0;i<cnt;i++)
	{
		data=*src++;
		realdata=data<<8;
		data=data>>8;
		data|=realdata;
		if(data!=0)
			data=data;
		if(data>=0)
		{
			data=256*8+(data+8)/16;
		}else
		{
			data=256*8+(data-8)/16;
		}
		*des++=data;
	}
	return length;
}

//*/

int pcm_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//--------H init
	unsigned int tmpreg1=0,tmpreg2=0;
	NVIC_InitTypeDef NVIC_InitStructure;  
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure; 
	
	pcm_Init_Shutdown_Pin();
	
	/* Enable peripheral clocks ------------------------------------------------*/
	/* GPIOA Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	/* DAC Periph clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
	
	//POA4
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	tmpreg1=DAC->CR;//Get the DAC CR value  
  	tmpreg1&=~(CR_CLEAR_Mask<<DAC_Channel_1);//Clear BOFFx, TENx, TSELx, WAVEx and MAMPx bits  
  	tmpreg2=(DAC_Trigger_Software|DAC_WaveGeneration_None|DAC_LFSRUnmask_Bit0);//|DAC_OutputBuffer_Enable);
  	tmpreg1|=tmpreg2<<DAC_Channel_1;//Calculate CR register value depending on DAC_Channel 
  	DAC->CR=tmpreg1;//Write to DAC CR 
	DAC->CR|=CR_EN_Set<<DAC_Channel_1;//DAC Channel1ʹ��,PA4�Զ����ӵ�DAC

	DAC->DHR12R1=0x00;//ͨ��1��12λ�Ҷ�������	
	DAC->SWTRIGR|=0x01;//������������ͨ����ת��
		
	//TIM3 10KHZ  
    TIM_DeInit(TIM3);                                          
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);       
    TIM_TimeBaseStructure.TIM_Period = 100;                    
    TIM_TimeBaseStructure.TIM_Prescaler = 72-1;                       
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;             
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);   
    TIM_ClearFlag(TIM3, TIM_FLAG_Update);                 
	
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    PCM_Priority();  
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
    NVIC_Init(&NVIC_InitStructure);  
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);               /* Enable TIM3  interrupt TIM3����ж�����*/ 

	//--------S init
	_pcm_dataAddr=0x00;
	_pcm_flags=0x0000;
	_pcm_currenrbuf=0;	//0:fill buf1 C_pcm_bufsize:fill buf2
	_pcm_pindex=0;
	_pcm_filelength=0;
	
	return 0;
}

void pcm_fillbuf() 
{
	u8 *pbuf;
	int rlength=0;
	if(0==(_pcm_flags&B_pcm_buf1))
	{
		pbuf=_pcm_buf;
		_pcm_flags|=B_pcm_buf1;
	}
	else if(0==(_pcm_flags&B_pcm_buf2))
	{
		pbuf=_pcm_buf+C_pcm_bufsize;
		_pcm_flags|=B_pcm_buf2;
	}
	else
		return;

	{
		if(_pcm_filelength>C_pcm_bufsize)
		{
			rlength=GettestData(pbuf,_pcm_dataAddr,C_pcm_bufsize);	//GetResourceData(pbuf,_pcm_dataAddr,C_pcm_bufsize);
			_pcm_dataAddr+=rlength;
		}else
		{
			#if 0
			if(0==_pcm_filelength)
			{	
				_pcm_dataAddr-=1;
				_pcm_filelength=1;
			}
			rlength=GettestData(pbuf,_pcm_dataAddr,C_pcm_bufsize);	//GetResourceData(pbuf,_pcm_dataAddr,_pcm_filelength);
			*(pbuf+_pcm_filelength-1)=0x00;
			#else
			if(_pcm_filelength<=2)
			{	
				_pcm_dataAddr-=2;
				_pcm_filelength+=2;
			}
			rlength=GettestData(pbuf,_pcm_dataAddr,_pcm_filelength);	//GetResourceData(pbuf,_pcm_dataAddr,_pcm_filelength);
			*(pbuf+_pcm_filelength-1)=0x00;
			*(pbuf+_pcm_filelength-2)=0x00;
			#endif
			_pcm_dataAddr+=C_pcm_bufsize;	//20160710 _pcm_dataAddr+=rlength;
			
			if((B_pcm_loop==(_pcm_flags&B_pcm_loop))&&(_pcm_backlength>=C_pcm_bufsize))
			{
				_pcm_dataAddr=_pcm_backAddr;
				_pcm_filelength =_pcm_backlength;
				#if 0
				rlength=rlength-1;
				#else
				rlength=rlength-2;
				#endif
				pbuf+=rlength;
				rlength=GettestData(pbuf,_pcm_dataAddr,C_pcm_bufsize-rlength);	//GetResourceData(pbuf,_pcm_dataAddr,C_pcm_bufsize-rlength);
				_pcm_dataAddr+=rlength;
			}
						
		}
		_pcm_filelength-=rlength;
	}
}

void pcm_checkmsg()
{
	if((_pcm_flags&B_pcm_IsPlaying)&&(_pcm_flags&(B_pcm_buf1+B_pcm_buf2))!=(B_pcm_buf1+B_pcm_buf2))
		pcm_fillbuf();
}

void PlayVoice(u16 index)
{
	pcm_Play(index);
}

void StopVoice()
{
	_pcm_flags=0x0000;
	GPIOB->BSRR = GPIO_Pin_10;//...close speak
	TIM3->CR1 &= ~TIM_CR1_CEN;	/*�ر�Timer3����*/  
}

void pcm_Play(u16 index)
{
	GPIOB->BRR = GPIO_Pin_10;//...openspeak
	
	TIM3->CR1 &= ~TIM_CR1_CEN;	/*�ر�Timer2����*/  
	TIM3->SR&=~(1<<0);//����жϱ�־λ 	
	#if 0
	_pcm_dataAddr=GetResourceItemAddr(Resource_audio,index);
	_pcm_dataAddr+=0x28;
	GetResourceData((u8 *)&_pcm_filelength,_pcm_dataAddr,4);
	_pcm_dataAddr+=0x04;
	#else
	_pcm_dataAddr=(u32)&_binary_asc5x7_bin_start;
	_pcm_filelength=54864;
	#endif
	_pcm_backAddr=_pcm_dataAddr;
	_pcm_backlength=_pcm_filelength;
	_pcm_flags=(B_pcm_IsPlaying);
	_pcm_currenrbuf=0;
	_pcm_pindex=0;	
	pcm_fillbuf();
	TIM3->CR1 |= TIM_CR1_CEN;                            /*����Timer2����*/
}

void pcm_SetLoop(void)
{
	_pcm_flags|=B_pcm_loop;
}

int pcm_IsPlaying()
{
	return _pcm_flags&B_pcm_IsPlaying;
}

u16 IsVoiceBusy()
{
	return _pcm_flags&B_pcm_IsPlaying;
}

u8 vflag = 0;

void TIM3_IRQHandler(void)  
{  
	if(TIM3->SR&0X0001)//����ж�
	{
		u8 data;
		u16 dcadata;
		#if 0
		data=_pcm_buf[_pcm_currenrbuf+_pcm_pindex];
		_pcm_pindex++;
		#else
		dcadata=(u16)(*((short *)&_pcm_buf[_pcm_currenrbuf+_pcm_pindex]));
		_pcm_pindex+=2;
		#endif
		if(_pcm_pindex==C_pcm_bufsize)
		{
			if(_pcm_currenrbuf==0)
			{
				_pcm_currenrbuf=C_pcm_bufsize;
				_pcm_flags&=~B_pcm_buf1;
			}
			else
			{
				_pcm_currenrbuf=0;
				_pcm_flags&=~B_pcm_buf2;
			}
			_pcm_pindex=0;
		}
		#if 0
		if(data==0)
		#else
		if(dcadata==0)
		#endif
		{
			StopVoice();			
			_pcm_flags&=~B_pcm_IsPlaying;
			data=0x80;
		}
		
//		DAC->DHR8R1=data;
		#if 0
		dcadata = (u16)((data << 4 | data>>4)*0.3);
		#else
		dcadata=(u16)dcadata*0.5;
		#endif
		DAC->DHR12R1=dcadata&0x0fff;	//ͨ��1��12λ�Ҷ�������

		DAC->SWTRIGR|=0x01;//������������ͨ����ת��
		TIM3->SR&=~(1<<0);//����жϱ�־λ 	
	}
}  



