/*
chanel
*/
#include "chanel.h"
#include "File.h"
#include "pcm.h"
#include "CMLIB.h"
#include "decode.h"

int chanel_fillbuf(pchanelData chanel) 
{
	PCM_CODE_DATA tmpbuf[C_pcm_bufsize];
	u8 *pbuf=(u8 *)tmpbuf;
	int rlength=0;
	int sampleNum;
	
	if(0==(chanel->flags&B_chanel_IsPlaying))
		return 0;
	
	if(chanel->filelength>C_pcm_bufsize)
	{
		rlength=GetResourceData(pbuf,chanel->dataAddr,C_pcm_bufsize);
		chanel->dataAddr+=rlength;
		chanel->filelength-=rlength;
	}else
	{
		rlength=GetResourceData(pbuf,chanel->dataAddr,chanel->filelength);
		pbuf+=rlength;
		chanel->filelength=0;
	
		if(B_chanel_loop==(chanel->flags&B_chanel_loop))
		{
			while(rlength<C_pcm_bufsize)
			{
				chanel->dataAddr=chanel->backAddr;
				chanel->filelength =chanel->backlength;
				int bufsize=C_pcm_bufsize-rlength<chanel->filelength?C_pcm_bufsize-rlength:chanel->filelength;
				rlength+=GetResourceData(pbuf,chanel->dataAddr,bufsize);
				pbuf+=bufsize;
				chanel->filelength-=bufsize;
				chanel->dataAddr+=bufsize;
			}
		}else
		{
			chanel->flags ^= B_chanel_IsPlaying;
		}		
	}
	
	sampleNum=rlength*2;
	decode(tmpbuf,rlength, chanel->buffer,chanel);
	return sampleNum;
}

//int chanel_fillbuf(pchanelData chanel) 
//{
//	PCM_CODE_DATA tmpbuf[C_pcm_bufsize];
//	u8 *pbuf;
//	int rlength=0;
//	pbuf=(u8 *)tmpbuf;
//	int sampleNum;
//	
//	if(0==(chanel->flags&B_chanel_IsPlaying))
//		return 0;
//	
//	if(chanel->filelength>C_pcm_bufsize)
//	{
//		rlength=GetResourceData(pbuf,chanel->dataAddr,C_pcm_bufsize);
//		chanel->dataAddr+=rlength;
//	}else
//	{
//		if(0==chanel->filelength)
//		{	
//			chanel->dataAddr-=1;
//			chanel->filelength=1;
//		}
//		rlength=GetResourceData(pbuf,chanel->dataAddr,chanel->filelength);
////		*(pbuf+chanel->filelength-1)=0x00;
//		chanel->dataAddr+=rlength;
//		
//		if((B_chanel_loop==(chanel->flags&B_chanel_loop))&&(chanel->backlength>=C_pcm_bufsize))
//		{
//			chanel->dataAddr=chanel->backAddr;
//			chanel->filelength =chanel->backlength;
//			rlength=rlength-1;
//			pbuf+=rlength;
//			rlength=GetResourceData(pbuf,chanel->dataAddr,C_pcm_bufsize-rlength);
//			chanel->dataAddr+=rlength;
//		}else
//		{
//			chanel->flags ^= B_chanel_IsPlaying;
//		}
//					
//	}
//	chanel->filelength-=rlength;
//		
//	sampleNum=rlength;
//	ccopy((u8 *)tmpbuf,(u8 *)chanel->buffer,sampleNum*sizeof(PCM_DATA));
//	return sampleNum;
//}


